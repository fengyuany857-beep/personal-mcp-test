# HDS Interlude V2 原位渐进重构实施表

2026-09-08 beta10 修正：针对 purge 后正文显著缩短，将写作任务置于协议之前，恢复生活剧本的展开空间，明确短台词与正文深度分别处理，并为无前段原文的起点增加正向生活引导。加入未注意、无法查看、忙于要事或暂不愿查看消息时继续生活的消息感知边界。撤回 beta9 的全局轻写暗示；不设字数门槛或重写检测。验证重点为清空后起点与长历史续写两种情境中的生活进展、正文细节、台词自然度及来源归属。

最新增量：主提示词向 0.1.1-beta6 的简明剧本任务靠拢，合并原文与续写说明，取消逐步互动分析及每轮环境铺陈要求，允许口语省略、自然气泡停顿和开放结尾。保持同一剧本、认知归属、时间边界及行动引用；不修改记忆或调度算法。283 项回归与类型检查通过；beta9 发布与桌面安装随本次执行。实机需比较当前话语回应、未完成生活承接及事实归属，而不以回复变短作为拟真度结论。

状态：当前修正版本为 **1.0.1-rc6**。在唯一剧本主链上汇总 P0-1/P0-2/P0-4、P1-1～P1-4、可选 Urge 调度、事件优先续写／Alter 收束／关系学习证据边界，以及生活剧本展开与消息感知提示词；P0-3 不实施。完整原始剧本仍是唯一续写正文，辅助记录只携带来源、角色视角、条件与调度，不把期待升级为共同事实。发布前自动测试、严格类型检查与构建通过；真实模型拟真度、多日运行与外部平台恢复仍待实机验收。详见 [P1 实现记录](development/P1_MEMORY_NAVIGATION.md)、[Urge 实现记录](development/URGE_SYSTEM_IMPLEMENTATION.md)、[事件优先修正](development/EVENT_LED_SCRIPT_REPAIR.md) 与 [更新记录](CHANGELOG.md)。下文 beta9 及旧里程碑保留作历史基线，涉及时间账本、实时 snapshot 与学习入口的旧描述，以本次状态和 [当前架构](ARCHITECTURE.md) 为准。  
起点：`0.1.5-beta10-foresight`  
架构依据：[SCRIPT_CENTRIC_ARCHITECTURE_REDESIGN.md](SCRIPT_CENTRIC_ARCHITECTURE_REDESIGN.md)  
实施方式：在当前唯一主链上逐步替换，不建设生产并行的 V1/V2 双引擎

## 1. 当前版本备份记录

### 2026-09-06 beta6 五项架构修复

备份：`../dustbin/source-backups/2026-09-06-before-beta6/`，包含修改前 src、test、docs、版本清单和用户文档。前一批尚未发布的导演原文承接、Alter 同来源累计对齐已保留并合入 beta6。

| 顺序 | 已实现变化 | 合作边界与验证 |
| --- | --- | --- |
| 1：剧本行动 | say 原话锚点 → actionId → 既有 transport；无行动显式记录，停止重复 realtime snapshot | 不从“发了一句”猜台词；无效新引用不代发，旧 content 兼容；流式已发内容、分段、群聊、跨关系、承诺结算仍走原执行器 |
| 2：时间交接 | director 是窗口内建议；new original-v2 原文是完成记录；计划不再写入持续 carry 或覆盖场景摘要 | 宿主时钟、导演失败重试、旧 ledger 兼容；原文保留未决联系，自主生活不被等待状态替代 |
| 3：局部场景 | lifeHandoff 引用本段地点、末端活动、在场表、结构变化及事项完成；场景来源版本防止旧整理回写 | 不用超时/轮数强制换场景，不重置 arc，不删除历史；无来源的旧在场断言退出当前视图 |
| 4：写作入口 | 从上一段完成处开始，强调新事件改变与实际反馈；保留完整原文，减少一份实时摘要竞争 | 普通/cache-first 两种 payload 保持新旧时间语义与执行注解一致；复用只观测，不裁剪/拒绝/重试 |
| 5：人物学习 | interactionEvidence 连接发言、用户反馈、解释和实际回应；支持性 review 才允许关系候选晋升 | 原跨场景、跨日、冷却和反证逻辑保留；缺反馈不增加场景置信度；不改变 Alter 情绪累计算法或新增情绪消退 |

后续顺序：在用户指定实例备份后安装 → 对照 18:43 重演、19:39 抗议、20:18 虚构发送、23:12 游戏等待四组记录 → 进行真实 30–50 轮高密度和长沉默交替测试 → 跨日回忆与 24/72 小时观察 → 再评估次级功能 backlog 和服务文件拆分。不要仅因单测通过宣布 V2 拟真度稳定，不回到“加一批限制/检测提示”的路线。

完整实现清单、测试性质和仍需实机验证的边界见 [beta6 修复报告](development/BETA6_ARCHITECTURE_REPAIR_REPORT.md)。以下为历史实施记录。

### 2026-09-05 beta5-m10 整体合作收尾

执行前备份：`../dustbin/source-backups/2026-09-05-before-beta5-m10/`。完整检查矩阵、闭环细节、测试与未完成门槛见 [M10 功能合作报告](development/M10_FUNCTIONAL_COOPERATION_REPORT.md)。

本次闭环修正：

1. 到期意图提供实际 ID；私聊只交付叙事任务，分段/浏览/主动检查各归专属执行器，不再被普通新消息提前完成。
2. 承诺的新建与解决绑定当前 script event 的完整实际投递；无关回复不自动兑现、末段失败/取消保持待处理，延期和原事件回放具备身份去重。先解决旧承诺再登记新承诺。
3. no-event/due-plan 回合不再生成 message-perceived 或错误更新已读；保留惦记、追问和所有原文。
4. 混合到期任务不阻塞已提交气泡；前台忙时只检查分段投递，不额外开后台叙事。
5. 写作提示与实际浏览/分段开关、自定义分隔符一致；侧端观察不再与 imageCount=0 的规则冲突。
6. 私聊跟进隔离其它关系的后台通信摘要；cache-first 继承完整 payload 后变换视图，减少漏传风险。
7. 无消息回合可用可见当前剧本查询相关人物倾向；不增加学习证据或权重，不改变最多两条、跨场景及反证条件。

后台通信摘要也在完整投递后登记，两个分段执行入口均补齐回写，摘要故障不影响发送。工程验证：严格类型检查、226 项测试（本轮新增17项）。本次没有真实模型/OneBot/浏览器网络调用，不能宣称所有功能已实机调用或所有组合拟真度必然提升。M10 在这里是 beta 工程收尾，不等于第15节长期稳定发布门槛全部通过；完整持久投递恢复、大文件物理拆分及历史数据修复依旧独立验收。

### 2026-09-05 beta5-m9 收尾记录（本次执行依据）

备份：`../dustbin/source-backups/2026-09-05-before-beta5-m9/`，含 src/test/docs/lib/package.json/README。没有读取密钥或复制运行数据库。删除项可从此恢复。

#### 续写修正：保留原文与联系悬念

beta10 的自动段落经 `timelineEntryPromptProjection` 替换成已完成事件账本，且短自动回合也通常经过时间导演。M7/M8 恢复原文并允许短窗口直写后，旧段落重演的风险暴露。修复不退回账本替代原文，不按时间间隔降低剧本精细度。

1. `script/continuation.ts` 建立来源型书签：已成立至何时、最后已完成剧本 ID、最近真实通信 ID。只引用实际送入上下文的原文，不另写状态摘要，也不凭沉默推断一笔“用户欠答”。已经实际送达但晚于剧本提交时刻的消息仍列为既成通信；本轮新来信由 incomingEvent 承载。
2. 主提示词把“接演”与“整场重写”区分开。等待、承诺、未决关系与生活动作同属一条因果链；再次问“在吗/想好了吗”可以是新的当下行动，不按相同台词认定重复。
3. 复用原有 activeConsequences、upcomingPlans、followUpCommitments 及投递现实；不新建联系悬念导演，不把等待用户决定强行转成主角待履约承诺。
4. 40 字长片段复用率仅输出 debug 观测；不裁剪原文、不拒绝提交、不自动重试、不用于人物晋升或人格权重。
5. 单气泡分隔符规范化与 commit 查找共同回归，修复 cannot reconstruct its content；不修改原始剧本文字。

#### M8 生产者—消费者审计与本轮处置

| 层 | 当前生产/消费 | 本轮决定 |
| --- | --- | --- |
| recentScript / Episode / facts | 原文提交、整理与来源检索 → 主叙事 | 保留原文与来源链，新增书签，不改召回权重 |
| scene / arc | 后台整理 → sceneContext、历史导航 | 保留；不重建或覆盖历史弧 |
| continuitySnapshot / workingDetails | 叙事连续性输出、整理 → 当前上下文 | 仍有消费者；保留现有生命周期，不与本次清理混合迁移 |
| memory | decision.memories → appendMemory → 查询/提示/管理命令 | 非死代码，不能按规划标题直接删表或删路径 |
| delivery ledger / summaries | 平台结果及兼容摘要 → 叙事与调度 | 保留；summary 仍有兼容生产路径，完全确定性替代未冒充完成 |
| timelinePlan / timelineCarry | 时间导演、宿主状态 → 主叙事 | 修复 cache-first 字段漏传；导演路由不额外改动 |
| development.* | 后台来源候选 → 跨场景晋升/反证 → 至多两条相关倾向 | 现有隔离/去重测试继续通过；多日效果待实机 |
| 旧 statePatch / overlay | 新自由路径应用已退出；旧记录仍参与 overlay 整理 | 不删除兼容读取，不清空历史人设 |
| ChatRhythm | 旧投递统计 → 已无写作消费者 | 删除计算和统计写入；旧配置/状态仅兼容保留 |

#### M9 删除边界与后续路线

本轮删除 `src/chat-rhythm.ts`、`src/script/legacy-adapter.ts`、废弃 ChatRhythm 单测及对应声明产物；原有 commit 测试直接进入生产 commit-builder。移除 NarrativeRequest 中无消费者的 ChatRhythmPrompt 协议。保留配置形状、状态 codec，隐藏已失效控制项，便于旧实例升级和回退。

M9 原规划要求“真实运行稳定后大拆分”。本次按用户指定的“删除完全无用的已弃用旧结构”执行安全子集，不在拟真度回归尚待观察时拆解 service/narrator 全文件。仍有调用的时间账本投影、消息兼容入口、memory 和旧 overlay 不能算完全无用。

下一步顺序：安装并进行混合消息/沉默的实机对照 → 验证未决联系能再次询问且不重演旧来信 → 跨日及24/72小时观察 → 单独处理剩余状态层迁移/摘要确定性投影 → 再完成大文件物理拆分和 M10 发布验收。这里的收尾是本轮工程闭环，不等同于原 M8 所有长期验收项通过。

验证：严格类型检查、209 项自动测试通过；新增气泡边界、两种 payload 顺序、联系悬念保留、旧状态回读，以及 40 轮混合事件上下文夹具。没有调用真实模型，因此不能据此承诺模型永不复写。历史重复剧本未被清洗，安装后应保留原数据进行对照。

开始实施前已经建立源码快照：

```text
../dustbin/source-backups/2026-09-04-beta10-before-v2-in-place/
```

备份包含：

- `src/`、`test/`、`docs/`；
- 当前 `lib/` 构建产物；
- `package.json`、TypeScript 配置和根级使用文档；
- `koishi-plugin-hds-interlude-0.1.5-beta10-foresight.tgz` 发布包。

校验结果：

- 共比较 82 个文件；
- 与原文件哈希不一致数量：0；
- beta10 发布包 SHA-256：`ACF0B752CAE70CD1C5ADEE95A0A4C14D6B74E96D197B1DAD1C64ECD390C4BE47`。

此备份只包含插件版本，不把包含账号、私聊和密钥的运行数据库及 `koishi.yml` 放入源码目录。进入数据库迁移步骤前，必须在 Koishi 实例目录之外另做一次运行数据备份，并验证能够恢复。

### 1.1 2026-09-04 实施记录

M1–M3 已在 beta10 的唯一主链上原位完成，没有增加并行引擎，也没有增加主模型调用：

- M1：新增版本化 `StoryState` codec，所有故事状态读取/写入统一经过 decode/encode；启动时一次性解析各模型任务路由；剧本持久化草稿与投递 metadata 由独立边界模块生成。
- M2：beta10 JSON 在规范化后单向转换为一个 `ScriptCommitDraft`；剧本 entry 保存完整 commit/event 清单；私聊、跨会话、群聊与拆分气泡携带同源 event 身份。
- M3：移除实时回合的固定 400–700 字、每轮“全新作品”和列举式反重复要求；改为按事件密度分配叙事精度，并由正在发生的动作、注意力与因果链组织连续剧本。

本次自动验证结果：TypeScript 严格 typecheck 通过；162/162 项测试通过；`lib/index.js` 已重新构建并可由 Node 加载；npm 发布包 dry-run 成功。尚未完成的门槛是 24 小时运行观察、脱敏连续场景回放和真实模型盲评，因此此记录不宣称拟真度已经被实测证明。

### 1.2 1.0.0-beta1 / M4 实施记录

- 从现有 scene、scenePresence、workingDetails、Agency 和可见 recentScript 确定性投影 `SceneFrame`；任何非空派生字段都保存具体 sourceEntryIds。
- `frameId` 只随 scene 身份变化；`DialogueBurst` 同样由场景边界决定，不读取消息条数或空闲时长。
- 主模型上下文已从平铺资料改为七段式续写支架；旧字段仅作为宿主内部准备数据，不再重复序列化为第二套提示上下文。
- beta10 兼容输出适配为带 frameId/burstId 的 `SceneDelta`，prose、消息及其它事件继续属于同一个 ScriptCommit。
- 共享 SceneFrame 不物化关系限定 prose；私聊和群聊原文仍只走原有可见性过滤后的 recentScript。
- 自动验证扩展为 166 项并全部通过；真实模型的高密度情节 beat 数和拟真度仍需桌面实例运行观察。

### 1.3 1.0.0-beta1 实机观察与路线修正

桌面实例已经证明 M4 的代码链路可运行，但未证明其叙事语义正确。2026-09-04 的连续对话暴露出三项阻断问题：

- `SceneFrame` 把上一段 narrator prose 的尾句写回 `narrativeFocus` 与 `postureOrMotion`，使温水杯、物理讲义、台灯、椅背和打字动作在连续回合中形成自我强化；
- 活跃 Scene 与 DialogueBurst 连续存活约 40 小时，跨越日期与多次活动变化，说明“burst 与 scene 同寿命”和模型自由决定 `scene.close` 均不足以表达真实生活边界；
- 前一日已经存在于原始剧本和长期事实中的事件，因事实候选在语义排序前被截断、原始剧本 embedding 未持久化且活跃场景未关闭，未能进入本轮上下文，模型随后错误否认该事件发生过。

这与 0.1.2 回滚文档记录的失败机制同源：结构化场景开始替代原始剧本的语义和写作纹理，并将自己的概括结果循环喂回下一轮。M4.1 因此不是给现有提示增加反重复补丁，而是恢复以下权威关系：

```text
近期原始剧本 / 命中的历史原文
  > 带来源的事实与 continuity
  > SceneFrame 导航证据
  > 无来源的推断
```

0.1.4 的剧本核心提示词重新作为主提示骨架。`recentScript` 是连续续写的第一上下文；SceneFrame 只为宿主检索、边界判断和原文窗口外的少量事实补位，不能保存 prose 表达，也不能成为“稳定续写点”。在 M4.1 的真实回放、跨日召回和 24/72 小时观察通过前，除不改变输出语义的 M5 提交边界初部署外，M5 完整收束及 M6–M10 冻结。

### 1.3 2026-09-04 M4.1 / M5 初部署记录（未打包）

- 主提示删除 SceneFrame 作为稳定续写点的权威声明，恢复 `recentScript → recalledScript → 低频事实 → currentSceneEvidence` 的原始剧本优先关系；
- 模型 payload 将 `currentSceneFrame` 降级为 `currentSceneEvidence`，隐藏 DialogueBurst，且来源已在 recentScript 中可见的场景证据不重复注入；
- SceneFrame 每轮只从来源化事实重投影，不再克隆 beta1 的 prose 尾句、姿态、情绪基线和 narrativeFocus；旧状态 codec 升至 v3 并在读取时清除这些字段；
- recentScript 条目下限提升到 50，保持 12K 原文预算和近期真实消息保护；
- 原始条目新增可空持久化 embedding 列和升级注册；历史召回改为语义、中文/英文词法与 fact.sourceEntryIds 三路并集，再回取命中点前后连续原文；无 embedding 仍可召回；
- durable facts 候选池改为宽而有界（300–1000），避免旧事实先被 importance top-N 截断；
- DialogueBurst 改由关系范围、话题因果和明确外部边界推进，不再按时间差或消息数变化；Scene 关闭必须携带可验证的 boundary 来源，`entryCount` 改为累计；
- M5 初部署把生产入口从 `legacy-adapter` 移到宿主侧 `commit-builder`，模型仍只写 script 与必要 transport 字段，commitId/eventId/frameId/burstId 继续由宿主生成；旧 adapter 仅保留兼容导出；
- 本批次不改包版本、不生成发布包、不安装桌面实例。自动测试通过后仍需完成固定失败夹具、同模型盲评及 24/72 小时实机观察，才能判定 M4.1 完成并继续 M5 收束。

### 1.4 2026-09-05 M5 补充收束记录

针对实机高密度对话仍反复出现“重建时间地点 → 看见消息 → 评价用户 → 敲字 → 收起手机”的固定形态，本轮只收束主模型协议和宿主提交边界，不改变数据库、投递策略或模型调用次数：

- USER MESSAGE phase 从“先补写生活、再让消息进入”的固定顺序改为从 `recentScript` 尚未写出的第一个变化继续；场景可以由动作、消息原文、身体反应、联想、注意转移或直接语言自然进入；
- 已经成立的地点、姿态和设备状态保持隐含，只有实际参与新因果时才重新获得篇幅；高密度对话仍保持相同叙事分辨率，细节转移到新增意义而不是被时间间隔压缩；
- 删除“考虑—草稿—打字—发送”作为每轮默认路线的暗示，可见回复只需成为当前剧本中真实发生的一个行动；
- transport contract 按私聊、群聊和独立生活推进分支生成：私聊不再常驻群聊 schema，群聊不再同时携带私聊 schema，advance 不再呈现为当前回复任务；
- continuity、Alter、Agency 和自动投递摘要只在本轮确实启用时出现；未启用功能不再通过成组的 `Do not output` 指令占据写作注意力；
- ChatRhythm 暂不删除，其模型侧地位降为可错的历史观察，不能指定气泡数、长度模板或剧本节奏，避免提前混入 M7 的物理删除；
- 宿主为即时 outgoing/group message 建立无模型调用的原文位置绑定。能够唯一定位时保存 bubble span；旧输出无法定位时标记 `unbound` 并记录诊断，但继续沿现有兼容投递链执行；未来 delayed action 标记为 `future`，不要求把尚未发生的发送写进当前 prose。

这一阶段不把 `unbound` 升格为重试条件，避免模型为了通过字符串检查形成新的引号模板。只有实机确认模型能稳定把可见原文自然写入剧本后，才考虑在后续提交边界将其变成硬一致性条件。

### 1.5 2026-09-05 M6.1 原位投递闭环记录

本阶段只改变“已提交行动如何记账”，不改主提示、剧本文本、消息正文、拆分方式、发送顺序、延迟或重试策略：

- 在权威 `script` entry 的 metadata 内为 outgoing/group/platform action 建立 `deliveryActions`，每项保留 commitId、eventId、行动种类和顺序稳定的 segments；
- 私聊、跨关系消息和延迟拆分气泡随投递句柄携带源 `scriptEntryId`，平台确认、失败或取消后回写源剧本行动；
- 群聊逐气泡保存成功/失败结果，`character-group-message` 仍只投影真正发送成功的气泡，部分失败不会再被整体成功状态覆盖；
- 贴图、原生表情与消息反应在宿主确认可执行后才进入 commit，并与平台完成记录共享相同事件身份；
- 已成功 segment 是终态，较晚的异常记账不能把它降级；重复确认是幂等操作；
- 没有新增数据库表、后台扫描器或第二发送器，因此 reload 不会因 M6.1 自行触发重发，现有信息投递路径保持唯一。

自动验证覆盖 181 项并全部通过，包含正文零改写、气泡重建、部分失败、幂等确认、源 entry 身份和 platform action 精确定位。M6.2 仍依照原计划等 M6.1 通过实机稳定性观察后再实施，不与本发布包同时引入。


### 1.6 2026-09-05 typ-0 桌面基座同步（bridge protocol 4）

桌面端（C:/dev/HDSI-desktop-typ-0）自 0.1.5-beta8-m6 直接跨到 V2。本轮在不动 V2 主链语义的前提下补齐桌面协同：

- 新增 `service.setDesktopDeliveryHandler()`：typ-0 worker 中 delayed/split/advance 投递此前必然 `bot-not-found` 失败（worker 无 adapter bot）。bridge 安装时注册宿主投递出口，后台消息经宿主 Outbox 投递，回执沿用 delivery-result Promise 语义，账本写入路径与实时回合完全一致（成功 → confirmOutgoingDeliveries → M6.1 账本；失败 → recordOutgoingDeliveryFailure）。普通 Koishi 不安装 bridge，零影响。
- `desktopTimelineEntryView` 升至 protocol 4：透传 `commitId`、`deliveryActions`（M6.1 账本摘要）、`sceneCheckpoint`（M7.1 检查点）。全部为 entry.metadata 的确定性只读投影，损坏字段安全省略，v2/v3 桌面端可忽略新字段。
- bridge-ready 上报 protocol 4。
- 桌面侧同步：normalizeEntry 白名单透传、Arrangement 投递现实/场景边界角标、Inspector 投递账本明细与日志深链接。
- 桌面端 `buildStoryYml` 缺 `http` 插件导致 worker 在 `inject=['database','http']` 解析阶段永久挂起——该缺陷由新端到端测试（fork 真实 worker，scripts/test-bridge-e2e.mjs）发现并修复；桌面工程依赖升级至 `1.0.0-beta4-m8`。
- 验证：HDSI 206/206（新增 protocol 4 投影回归）；桌面 runtime 20/20；端到端 bridge 测试 9/9（bridge-ready 4 / timeline-range / phase 闭环 / snapshot 兼容）。

## 2. 实施约束

#### 1.6.1 投影增强只读性审查（同日）

对 protocol 4 投影改动做了系统性只读性审查，结论：**A2/A3 对 HDSI 全部既有功能零影响**。

1. 引用审计：本轮在 service.ts 新增的 `commitId/deliveryActions/sceneCheckpoint` 引用仅 3 处（109/126/155 行），全部位于三个投影函数体内；其余同名引用（2452/2499/4063 行历史召回、4969/4976 行 M6.1 账本写入）均为本轮之前已存在的功能，未被修改。
2. 写操作审计：`desktopDeliveryRealitySummary`、`desktopSceneCheckpoint`、`desktopTimelineEntryView` 三个函数体内无任何 `dbSet/appendEntry/createScriptDeliveryActions/updateScript` 调用——纯读 metadata、返回新对象。
3. 内部消费者审计：`protocol: 4` 仅存在于两个投影返回出口，HDSI 内部无任何代码读取该数字；桌面端 `>= 3` 门控对 4 自动通过。
4. 健壮性 fuzz：新增测试覆盖 null/数字/字符串/半损坏 sceneId/NaN/超长数组等敌对 metadata 形态，投影始终返回合法结构、不抛错（207/207）。
5. 端到端字段白名单：e2e 测试（现 11 项）验证真实 worker 的 range 响应根对象与 entry 对象只含已知字段——IPC 投影边界无未知字段泄漏。

### 2026-09-05 M7.2～M8 源码构建与 subtle 优化（当前执行状态）

用户授权在 M7.1 源码基础上继续构建。恢复点：`../dustbin/source-backups/2026-09-05-before-m7.2-m8/`。本批保留唯一 script-first 主链和 24K 原文软预算，不增加实时主模型协议字段，不打包、不安装、不修改运行数据库。以下实施记录优先于历史章节中的“当前只允许 M4.1”等旧状态；完成源码不代表通过实机门槛。

| 范围 | 已实施 | 期望影响 |
| --- | --- | --- |
| M7.2 事件导航 | 后台整理可提出人物/地点/物件/话题/承诺/结果/日期标签；宿主只保留来源原文中的精确子串，附着 entry metadata，可由原文与 metadata 重建缓存 | 以具体事件找到原文，减少相似道具和文风主导召回 |
| M7.2 召回窗口 | 排除集合与真正进入 24K payload 的条目一致；命中段完整保留，优先补后续结果，过长邻段跳过；显式保留归属标签和 sourceEntryIds | 减少“已读取但未注入”形成的记忆盲区，降低把主角想法当成用户发言的风险 |
| M7.3 节奏 | 审查确认 ChatRhythm 只在首条投递确认路径以完整行动全文做统计，拆分续段不另调用；继续保持无模型侧 drift 注入 | 保持现有自由表达；旧统计按计划全文而非已全部送达全文解释，不宣称平台全部成功 |
| M8.1 原文与时间 | 实时 recentScript 保留自动窗口原文，另附 timelineEvidence；两种 payload 顺序一致；时间导演仍使用紧凑时间投影 | 恢复自动生活的原文质感，同时保留时间边界证据 |
| M8.1 调用路由 | 20 分钟内、同一日期且未跨已知日程起止点的 follow-up/intent-due 直接续写；advance、较长窗口和结构边界保留导演；导演熔断后保留游标等待恢复 | 减少短后续的调用负担；不让大段空档在失败后自由猜测。20 分钟只影响任务路由，不改变文笔精度或切场景 |
| M8.2 记忆消费 | facts 传递 unresolved/sourceEntryIds；整理器看到受隐私过滤的 deliveryReality，区分发送、平台接受、未确认与取消；workingDetails 支持有来源 resolved 删除 | 计划不再因状态字段丢失被误读为已完成，小事项不在处理完后反复出现 |
| M8.3 学习候选 | 受控维度以 development.* 路径存入现有 proposal 表；首次只观察，同 Scene 不增权，需新独立 Scene 才能晋升；同来源重放不能晋升 | 高频聊天不会加速固化人格；倾向变化更慢 |
| M8.3 反证与投影 | 新证据明确反驳同一条件下的倾向时降低置信度并将该新式候选/倾向标为 rejected；新支持重新开始观察。生效倾向按当前话题选最多两条，附原文来源，关系分支隔离 | 保留修正空间，避免每轮复述同一习惯；反证判断仍依赖后台模型质量 |
| 原文持久化 | script 入库不再经过通用 12K 字符裁剪；正文不因索引或时间整理改写 | 长篇原始剧本不在保存时丢失尾部；已有被截断历史无法凭空还原 |

学习维度：character 的 traits/preferences/coping；perspective 的 values/interpretation；relationship 的 trust/closeness/boundaries；world 的 established。新的自由路径停止接受。旧提案及旧已应用 overlay 保留为历史，不自动映射含义不明路径，不批量删除；新倾向不追加进永久 overlay，也不进入旧的周/月 overlay 压缩器。重大变化同样需要第二次独立场景观察，不以单次高置信度绕过观察周期。

生产者—消费者核对：

| 层 | 生产者 → 消费者 | 来源与生命周期 |
| --- | --- | --- |
| 原始剧本 | 单次主叙事提交 → 实时续写/历史召回/后台整理 | entryId；永久原文，窗口仅选择 |
| 场景/剧情弧 | 增量整理 → 主模型连续性上下文 | scene checkpoint 和本批原文；仍沿 M7.1 更新 |
| Episode 标签 | 同次后台整理 → 历史缓存与召回排序 | 字面来源验证；可丢弃重建，无独立模型调用 |
| facts | 后台整理 → 多路召回/事实提示 | sourceEntryIds、unresolved；旧 fact schema 保持 |
| workingDetails | 后台整理 → ongoingThreads | 明确完成删除或到期淡出，不自动发送消息 |
| memory 表 | 主模型 memories → 实时 memories | 确有独立生产/消费，保留；本批未证明删除安全 |
| deliveryReality | 现有投递账本 → 实时/后台整理 | commit/event/source entry；平台接受不代表已读 |
| timelineCarry | 时间结构提交 → 后续自动窗口 | 沿原宿主归一化，不添加 prose 尾句 |
| development.* | 来源化后台候选 → 相关场景的软倾向 | 跨场景观察、分支范围、反证退役；不改 Canon |

兼容边界：旧自动原文可能含时间越界，实时端现在同时呈现时间证据，必须在实机回放中验证模型遵循情况；保持只看账本的时间导演路径。未实现“仅凭日程就替代长窗口导演”，因为现有日程是计划、不能证明活动发生。旧弧重建、旧自由路径的逐项人工语义映射和 M6.2 事务恢复另列后续工作。语义标签属检索增强，不能作为事实已发生的证明。

后续顺序：先在冻结输入上验证跨日承诺、已完成事项、无输入推进、自动原文时间冲突和关系隔离，再进行打包后的 24/72 小时观察；验证合格后再执行 M5 行动引用收束、M6.2（有运行证据时）及 M9 物理清理。M10 保留连续剧本盲评，不以一条回复的流畅度替代评价。

工程结果：严格 TypeScript 检查通过，205/205 项测试通过，新增 10 项测试覆盖原文/时间证据的两种 payload 顺序、标签来源、归属、独立场景学习、重复输入不晋升、反证退役、关系隔离、短窗口路由、长窗口熔断、已完成小事项及长剧本存储。候选提示限 12 条、每条倾向 300 字；标签任务优先完成 scene/arc，再可选标注最多三条事件原文，避免辅助任务挤掉核心整理输出。仍未进行真实模型盲评或安装；运行可行性与拟真度只报告预期，不报告未经测量的提升百分比。

### 2026-09-05 新 M7.1：原文保留与剧情弧恢复（优先于以下历史路径）

本编号指 M7 发布后的修正批次，不等同于历史 M7.1 检查点子任务。目标是让已有 arc/scene 在唯一后台整理链中持续消费原始剧本，保留剧本核心。源码恢复点：`../dustbin/source-backups/2026-09-05-before-m7.1/`。本批次不迁移数据库、不打包、不安装。

审查修正：非文本占位并不等于伪平台事件，纯图片也会进入该分支；现有日志不足以判定用户所报幻觉全部由它造成。active scene 长和 arc 摘要短是症状，不能单凭这些统计断言模型或场景关闭完全失效。已确认的实现缺陷包括增量输入截取尾部后推进游标、空整理结果也推进游标，以及关闭场景使用模型完成时间可能跳过并发到达原文。

| 实施顺序 | 修正内容 | 验证要求 |
| --- | --- | --- |
| 1 | 增量整理改为有界完整前缀，按 id 排序，不跳过预算外较早原文 | 多批积压覆盖每条原文，超长单条完整保留 |
| 2 | 整理输入补充检查点前最多 12 条/约 8K 原文，仅作前情，不重复累计事实证据 | 沿用关系隐私过滤；已处理来源不计入本轮新证据 |
| 3 | 每次整理提供 scene/arc 有效摘要；先持久化弧，再确认场景游标 | 空结果及弧写入失败不能确认新游标；沿现有退避重试 |
| 4 | 用正向因果编辑提示维护起因、选择、关系变化、承诺原条件和已发生结局；主动审阅有来源的活动转换 | 不按消息密度或固定间隔切场景，不新增主模型调用 |
| 5 | 场景在已处理批次的末条原文处闭合，新场景继承已处理 id | 整理期间到达的原文仍进入下一轮；相同时间戳不重复消费 |
| 6 | recentScript 预算从 12K 提高到 24K，保留窗口边缘完整原文条目 | 无尾部片段改写；允许一个完整条目超预算，近期真实消息保护保留 |
| 7 | 空内容不生成泛化用户消息占位；图片保留明确媒体事件和未知内容语义，语音保留原转写链路 | 图片、表情、语音正常接入；空事件不打断在途回合 |

剧情弧仍是已发生因果和开放事项的导航，原始剧本拥有解释权；不把摘要当成未来剧情指令。场景边界暂落在本次已处理批次末尾，尚不支持模型在批次中间精确切分多个场景。未重放历史已跳过的条目，也未改写任何运行数据；历史信息仍可由原文召回，必要的旧弧重建需另行在备份副本验证后部署。

后续路径：先完成本批次工程回归，再在打包获授权后观察跨日约定、无消息推进、图片未知语义和 arc 摘要更新；观察通过后继续 M5 行动引用收束和 M7 索引补充，再进入 M8。24K 原文会增加输入 token；不将自动测试通过视作拟真度或长期记忆已得到实机证明。

本次验证：`npm run typecheck` 通过；`npm test` 195/195 通过。新增测试覆盖积压逐批无跳读、超长原文保留、空/不完整整理结果、弧写入失败、批次闭合游标及纯图片事件。旧投递、语音、时间导演、关系隔离、节奏诊断等回归通过。版本仍为 `1.0.0-beta4-m7`，未更新 lib、未创建发布包、未安装实例。尚未完成真实模型跨日回放、旧弧重建及 24/72 小时观察；存量事实/场景多表写入仍不具备完整事务恢复，本批次不宣称修复所有崩溃窗口。

### 2026-09-05 审查后的执行路径（优先于历史完成声明）

本次轻量修复：M6 账本读取/写入异常在统一更新边界记录告警后返回，允许既有确认流程继续创建后续气泡和执行平台动作；状态聚合只有实际存在 delivered segment 才能成为 partial；拆分消息未确认且准备重试时，保留 pending 并记录原因，不猜测平台一定未收到。发送策略、剧本正文、主提示、版本号和 Desktop 安装均不变。

这仍是观察性账本，记账失败可能留下陈旧状态；原有 character-message/intent 持久化失败和发送后进程退出的事务缺口尚未解决。不得将“幂等更新 metadata”表述为“幂等平台发送”。

| 顺序 | 实施内容 | 验收依据 |
| --- | --- | --- |
| 1（本次） | 隔离 M6 账本异常，修正聚合语义，记录拆分重试未确认状态 | 注入账本读写失败后，后续气泡仍创建，正文相同 |
| 2 | 将同一剧本行动的真实结果确定性投影到续写上下文 | 群聊部分失败、平台动作失败和取消都可见；不改写原始 prose，不暴露内部重试表 |
| 3 | 提前实施 M7.3：停止 ChatRhythm drift 模板指令注入，保留诊断 | 同模型连续场景对照；无固定气泡数指令，解析和投递无回归；统计区分计划全文和已送达内容 |
| 4 | 收束 M5 局部剧本行动引用 | transport 可追溯同一行动；不将全文字符串命中升级为机械重试，不要求模型填写完整事件图 |
| 5 | M7.1/7.2 原文场景检查点与 EpisodeIndex | 跨日命中后回取连续原文；可重建，关系隔离，无摘要文风自复制 |
| 6 | M8 时间、记忆消费者及低频人物发展收敛 | 事实区分计划/实际/未知；跨 Scene 证据晋升、反证与去重，不从重复修辞学习人格 |
| 7 | 按运行证据评估 M6.2，再进行 M9 清理和 M10 发布评估 | 发送后崩溃、reload、确认丢失测试；明确平台不支持幂等时的未知结果处置，避免盲目重发 |

M6.2 若因实机重复发送等证据成为阻断，可提前处理其事务边界，不必等待 M8；没有此类证据时不为表结构完整性迁移。每一步单独验证，不把文学效果与工程测试通过等同。既有 182 项测试通过记录属于上一发布版本；本次严格类型检查和 184/184 项测试通过，新增账本读取/写入异常注入及混合状态聚合回归。未构建发布产物、未打包、未安装。

### 2.1 始终只有一条运行主链

整个改造遵循以下规则：

1. 生产环境中，同一轮只调用一次主模型；
2. 不让 V1 和 V2 同时生成同一轮剧本；
3. 每个里程碑直接替换主链中的一个明确环节；
4. 临时适配器只能单向工作，例如把旧输出转换为新的内部 `ScriptCommitDraft`，不能长期维护两套语义；
5. 版本比较只在离线、冻结输入和数据库副本上顺序回放；
6. 每一步都必须可以通过恢复代码快照和对应数据库备份回退。

### 2.2 每步只改变一个主要变量

禁止在同一个里程碑中同时改动：

- 主提示词的中心写作方式；
- 模型输出协议；
- 数据库表结构；
- 长期学习算法；
- 消息投递语义。

一次只改变其中一个轴，其余部分通过适配器维持原行为。这样才能判断真实感变化来自哪里，也能让每次修正保持 subtle。

### 2.3 正向写作框架优先

文学表现、连续性、节奏和人物感由正向上下文引导；确定性的宿主检测只保留给不能交给文风解决的问题。

| 问题类型 | 首选手段 | 保留硬校验 |
| --- | --- | --- |
| 场景连续性 | 提供近期原始剧本；只在原文窗口不足时补充带来源的当前场景证据 | 拒绝无因果来源的地点、时间跳变 |
| 人物语言 | 提供人物习惯、关系语境和正向声音锚点 | 只校验消息与剧本是否逐字一致 |
| 剧本节奏 | 提供当前叙事焦点和开放动作 | 不再按字数、段数或结尾形式拒绝 |
| 情节自然性 | 提供可继续发展的因果锚点 | 只拒绝越过世界事实的事件 |
| 回复时机 | 在剧本中提供设备、注意力和生活状态 | 只校验不可能的行动能力和时间 |
| 长期发展 | 提供带来源的剧本证据 | 只阻止无证据写入稳定人格 |
| 投递 | 剧本生成完整消息事件 | 严格校验事件身份、原文和投递结果 |

宿主验证器不评价“写得好不好”，也不通过重复重试逼模型写成某种模板。它只守住时间、身份、权限、数据结构和已发生事实。

## 3. 正向提示框架的迁移目标

原提示词中的限制式表达应按下表逐步替换。每次替换后先回放和观察，不一次性重写全部 system prompt。

| 原限制式表达 | 新的正向框架 |
| --- | --- |
| 不要像问答助手一样回复 | 新消息进入主角正在发生的生活；续写它实际造成的感知、动作和语言 |
| 不要重复上一轮结构 | 从上一段尚未完成的动作、情绪和话题自然接续，让形式由当前焦点产生 |
| 每轮写 400–700 字 | 赋予每个新事件稳定而完整的因果与感官重量；篇幅随新增事件自然形成 |
| 不要虚构新事件 | 当前可发展的因果锚点包括这些外部事件、未完成动作、日程边界和环境观察 |
| 不要总以收手机或回到老师结尾 | 在权威现在停止，保留仍在进行的动作、注意力和未说完之处 |
| 不得添加 timelinePlan 外的事件 | 这个时间窗口提供以下可发生的 beat，沿它们渲染连续生活 |
| 避免相同气泡结构 | 在类似生活状态下，她通常在这些表达范围中自然变化 |
| 不要把临时情绪写入人格 | 稳定发展由这些跨场景证据支持；当前情绪继续作为场景状态存在 |

固定提示词最终只描述“这个世界如何继续”，不再像检查清单一样反复告诉模型哪些句子不能写。

## 4. 总体改造顺序

| 顺序 | 里程碑 | 主要变化 | 是否改变用户可见行为 |
| --- | --- | --- | --- |
| M0 | 冻结基线和备份 | 固定 beta10 恢复点、评测输入与指标 | 否 |
| M1 | 收紧内部边界 | 提取状态编解码、模型路由和持久化边界 | 否 |
| M2 | 建立内部 ScriptCommit | 将现有单次输出单向转换成统一剧本提交 | 原则上否 |
| M3 | 正向主提示词第一轮 | 替换固定篇幅、全新作品和反重复禁令 | 是，轻微 |
| M4 | SceneFrame 上下文（已实施，待校正） | 七段式编译器和 SceneFrame 已进入主链，但实机出现结构抢占原文的问题 | 是，已有退化 |
| M4.1 | 原始剧本主权恢复 | 恢复 0.1.4 提示骨架、原文第一解释权、跨日原文召回与事件式场景边界 | 是，目标是恢复并超过基线 |
| M5 | Script-first 提交收束 | 主模型继续专注写剧本；宿主从已提交剧本和必要 transport 字段建立事件身份 | 原则上否 |
| M6 | 投递闭环 | 以同一 ScriptCommit 内的消息动作为唯一投递源，保存气泡结构和结果 | 用户文本不应变化 |
| M7 | 场景检查点与 EpisodeIndex | 在已提交原文之上建立低频场景、burst 和事件索引，不反向替代原文 | 后台为主 |
| M8 | 记忆、时间与人物学习收敛 | 原文回取、时间导演瘦身和带证据的渐进学习 | 是，缓慢出现 |
| M9 | 删除旧结构 | 移除无消费者字段、负向节奏机制和临时适配器，完成物理拆分 | 否 |
| M10 | 整体可行性与拟真度验收 | 迁移、压力、跨日回放、长期运行和人工盲评 | 否 |

M1–M2 已建立可控边界，M3 改变了第一层写作方式，M4 的实机结果则证明结构化续写支架不能取得原始剧本的解释权。现在必须先完成 M4.1，再由 M5–M8 依次收束提交、投递、索引和学习。不能在 M4.1 未通过时继续叠加事件 schema，也不能从 ChatRhythm、statePatch 或时间导演各打一个补丁开始。

## 5. M0：冻结基线和建立评测夹具

### 目标

在改变行为前留下可重复的 beta10 运行基线。

### 实施项

- [x] 建立 beta10 源码和构建快照；
- [x] 校验快照文件哈希；
- [ ] 从运行数据库制作脱敏的只读回放夹具；
- [ ] 选取至少 30 个连续场景，而不是 30 条孤立消息；
- [ ] 场景集中必须同时包含低密度生活、高密度对话、自动推进、延迟回复、沉默、承诺到期和投递失败；
- [ ] 保存每个场景起始时的 story、participant、recentScript、facts、continuity 和 schedule 输入；
- [ ] 保存 beta10 的单次顺序回放结果、耗时、token、解析次数和最终投递事件；
- [ ] 建立高密度放大夹具：相同语义分别以 1、5、10 条连续消息进入，观察场景和学习是否随消息数量失真。

### 建议新增文件

```text
test/fixtures/replay/
test/replay-baseline.test.ts
test/density-stability.test.ts
docs/development/V2_EVALUATION_PROTOCOL.md
```

夹具只能使用脱敏或合成内容，不把真实私聊直接提交进仓库。

### 完成门槛

- `npm run typecheck` 通过；
- 当前 152 项测试全部通过；
- 同一夹具重复回放时，宿主侧输入、持久化顺序和指标统计一致；
- 能区分模型随机变化与插件逻辑变化。

### 回退

本阶段不改变运行行为，不需要数据回退。

## 6. M1：先重构内部边界，不改写作行为

这是应该首先实施的代码重构。没有这一层，后续任何提示词或状态变化都会继续被 `service.ts` 的大函数和 `story.state` 静默覆盖。

### M1.1 提取版本化状态编解码

#### 当前问题

`normalizeStoryState()` 位于 `src/service.ts` 尾部，手工挑选字段。ChatRhythm 已证明漏掉一个字段就能让完整功能失效。

#### 改动

- 新建 `src/story-state.ts`；
- 定义 `CURRENT_STORY_STATE_VERSION`；
- 实现纯函数 `decodeStoryState()`、`upgradeStoryState()` 和 `encodeStoryState()`；
- 所有读取先 decode，所有写入使用基于最新版本的窄更新；
- 升级函数必须幂等；
- 已知字段不得静默丢失；
- 未知未来字段放入显式 `extensions`，不能悄悄复制或删除；
- 给已有故事补齐 Perspective 基础值的迁移入口，但此里程碑先只报告，不自动改变人格内容。

#### 涉及文件

- `src/types.ts`
- `src/service.ts`
- `src/story-state.ts`（新增）
- `test/story-state-codec.test.ts`（新增）
- `test/database-normalization.test.ts`（新增）

#### 验证

- [x] beta10 状态 decode → encode 后语义等价；
- [x] `chatRhythm`、Alter、Agency、continuity、workingDetails 和 timelineCarry 全部保留；
- [x] 同一状态运行两次升级结果完全相同；
- [x] 缺字段的老故事能读取；
- [x] 新字段经过 codec 重载仍存在；真实数据库重启验证留到运行观察。

### M1.2 统一模型任务路由

#### 改动

- 新建 `src/model-routing.ts`；
- 在启动时一次性解析 main、compaction、timeline、alter、vision、embedding 的最终 provider 和 model；
- 后续调用只使用解析结果，不再在调用现场重新扫描 provider；
- 日志显示任务、provider 标签、model 和协议模式，但不显示 endpoint 密钥或请求正文；
- 路由无效时只禁用对应任务或明确失败，不跨任务类型盲目回退。

#### 验证

- [x] 当前配置解析结果与实际日志调用一致；
- [x] embedding provider 不会被当成聊天模型；
- [x] 被显式分配的模型不会被另一个旧字段静默覆盖；
- [x] 路由是启动时不可变解析结果，reload 后由同一纯函数重建。

### M1.3 抽出持久化和投递边界

#### 改动

先不改变数据库结构，只把现有大函数拆出明确接口：

```text
decision result
  → normalize narrative result
  → persist narrative turn
  → prepare outgoing deliveries
  → confirm delivery outcomes
```

建议新增：

```text
src/turn-persistence.ts
src/delivery.ts
```

`service.ts` 保留队列和调度，不再直接拼接所有数据库字段。

#### 验证

- [x] 使用现有模型输出时，核心数据库写入顺序与 beta10 一致；
- [x] 用户消息、剧本、角色消息和 intent 状态不减少；
- [x] 失败投递仍不会被确认成已送达；
- [x] 群聊、私聊和拆分消息测试全部通过。

### M1 总体验收

- 用户可见文本和发送时机与 beta10 无结构性变化；
- 全套测试和类型检查通过；
- 连续运行至少 24 小时无新增状态丢失、重复投递和队列阻塞；
- 完成后再进入提示词改造。

## 7. M2：建立内部 ScriptCommit，不改变主模型协议

### 目标

先让插件内部只处理一种“剧本提交”，但暂时继续接受 beta10 的模型 JSON。这样可以先稳定持久化语义，再要求模型学习新协议。

### 改动

新增：

```text
src/script/contract.ts
src/script/legacy-adapter.ts
src/script/validator.ts
```

定义最小内部协议：

```ts
interface ScriptCommitDraft {
  script: string
  events: ScriptEventDraft[]
  continuityDelta?: unknown
  sourceFormat: 'beta10'
}
```

`legacy-adapter.ts` 完成单向转换：

- `decision.script` → 剧本 prose；
- `interaction.reply` → `OutgoingMessageEventDraft`；
- action、sticker、promise 和 intent → 对应剧本事件；
- 所有事件获得本轮稳定的 `commitId` 和 `eventId`；
- 下游持久化与投递只接受 `ScriptCommitDraft`，不再读取原始 decision。

这不是双引擎。主模型仍只运行一次，适配器只是当前输出进入新内部边界的唯一入口。

### 初始存储方式

此时不立即加表。先利用 `interlude_script_entry.metadata` 保存：

```json
{
  "commitId": "...",
  "eventId": "...",
  "eventKind": "outgoing-message",
  "causedByEventIds": [],
  "bubbleIndex": 0,
  "bubbleCount": 2
}
```

避免同一里程碑同时改变模型协议和数据库 schema。

### 涉及文件

- `src/types.ts`
- `src/service.ts`
- `src/turn-persistence.ts`
- `src/delivery.ts`
- `src/script/contract.ts`
- `src/script/legacy-adapter.ts`
- `src/script/validator.ts`
- `test/script-commit-adapter.test.ts`
- `test/script-event-persistence.test.ts`

### 验证

- [x] 每个成功剧本只有一个 commitId；
- [x] 所有拆分气泡共享同一个 outgoing eventId；
- [x] bubble 顺序和完整原文可从 metadata 无损重建；
- [x] 新生成的已投递消息可追溯到所属剧本提交；
- [x] 适配前后的用户可见文字逐字相同；
- [x] 模型调用次数不增加。

### 回退

metadata 新键对 beta10 读取无害。恢复 M1 代码即可忽略它们，不需要删除数据库记录。

## 8. M3：第一轮正向主提示词迁移

这是第一次有意改变写作行为，但只改固定主提示词，不同时修改 payload、输出 schema 或数据库。

### M3.1 先删除三个冲突源

从 `src/narrator.ts::systemPrompt()` 删除：

1. 每个实时回合 400–700 字；
2. 每轮是全新作品而非系列下一段；
3. 通过列举旧开头、旧动作和旧结尾来要求反重复。

不要用另一组禁令替换它们。

### M3.2 加入短小的正向连续剧本核心

建议固定核心不超过约 8–12 条语义规则，中心表达为：

```text
Continue the protagonist's already-running life from the final established
moment to the authoritative present. The incoming message is one new event
inside that life. Let attention, action, feeling and any message grow from the
current scene. Carry unfinished movement and subtext forward. Give every new
event enough concrete detail to remain stable in later scenes. Stop at the
present with whatever is genuinely still in motion.
```

中文含义应保持为：

- 延续已经发生的生活；
- 新消息进入生活，而不是要求回答；
- 从现有动作、注意力、情绪和关系中长出后续；
- 每个新增事件获得足够稳定的具体性；
- 在真实现在停止，并保留自然未完成状态。

### M3.3 不再用格式惩罚文学变化

- 空 script 仍是协议失败；
- 时间越界、消息原文不一致仍是协议失败；
- 字数、段落数、开头形式、结尾动作不再触发重试；
- 重复风格先只记录指标，不向模型注入反向命令。

### 新增测试

```text
test/positive-narrative-prompt.test.ts
test/script-length-independence.test.ts
test/serial-continuity-prompt.test.ts
```

### 验证

- [ ] 高密度回合不会因时间短自动降级叙事精度；
- [ ] 同一场景连续三轮不会被写成三篇重新开场的短篇；
- [x] 提示协议和内部事件结构都要求回复处于剧本因果中；真实模型表现留待连续场景盲评；
- [ ] 平均剧本字数可以变化，但无事件丢失率上升；
- [ ] 主模型解析成功率不低于 beta10 基线；
- [ ] 离线人工盲评中，连续感优于 beta10，且没有明显问答器化。

### 发布观察

先在少量连续场景运行，不立即启动新的学习算法。这样任何变化都能归因于提示框架本身。

## 9. M4 / M4.1：从 SceneFrame 主导校正为原始剧本主导

### M4 已实施部分

M4 已建立 `SceneFrame`、`DialogueBurst` 和七段式 context compiler，并验证了来源 ID、共享剧本隐私和 legacy/cache-first 事实等价。这些工程边界继续保留，但 1.0.0-beta1 的实机对话证明其权威关系需要校正。

### M4.1 目标

恢复 0.1.4 已验证的自然语言连续性：主模型首先阅读近期原始剧本和命中的历史原文，再借助少量带来源的事实继续写同一部生活剧本。SceneFrame 是导航证据，不是剧本摘要、写作模板或续写稳定点。

M4.1 必须守住四项不变量：

1. 用户消息仍只是进入当前生活的一项外部事件；
2. 回复必须是同一段剧本因果链中的可见动作；
3. 原始剧本不可由 SceneFrame、事实、logical turn 或摘要替代；
4. 不按消息间隔、消息条数或固定字数改变剧本精细度。

### M4.1-A：冻结实机失败夹具

- 备份 1.0.0-beta1 的源码、发布包、桌面实例配置和数据库；
- 保存“温水杯/物理讲义/台灯”连续复读片段；
- 保存“星期二男孩 13/27”前一日发生、次日错误否认的完整原始条目、事实候选排序和模型 payload；
- 固化 0.1.4 system prompt、recentScript 投影与 12K 原文预算为对照快照；
- 记录同一模型、温度、人物设定和输入序列，后续回放不得改变比较条件。

### M4.1-B：恢复 0.1.4 剧本核心提示词

以 0.1.4 的主提示骨架为准：模型是长期生活剧本的主叙事作者，主角及其正在展开的生活始终是重心，消息只是进入生活的一个事件。

提示词权威顺序调整为：

```text
currentEvent：本轮唯一的新事件
recentScript：紧邻本轮的连续剧本原文，续写第一依据
recalledScript：按当前事件命中的历史原文片段
continuity / facts：原文窗口之外的低频事实辅助
currentSceneEvidence：必要时补位的带来源导航证据
```

删除“`currentSceneFrame` is the stable point of continuation”及把七段式字段描述为同等写作支架的表达。改用短小的正向核心：阅读已经发生的剧本，理解尚未完成的动作、关系温度和潜台词，让当前事件进入其中，并写出同一部剧本的下一段。

增加认知边界：召回内容是人物此刻能够自然想起的相关经历，不是完整档案；没有命中不是“从未发生”的证据。证据不足时，以迟疑、模糊印象或承认暂时想不起来继续剧情。

### M4.1-C：给 recentScript 建立不可绕过的完整性门槛

- 正常已有故事的实时回合必须含非空 `recentScript`；数据库有可见历史而编译结果为空时，本轮作为上下文故障处理，不静默生成；
- 保留条目下限与时间窗口的并集，起始配置维持至少 50 条和至少 12K 原文字符，并离线比较 12K/16K；
- 最近真实收发消息受单独保护，不因较长 narrator prose 被字符预算挤出；
- `recentExchange` 只强调真实收发消息和已投递动作，不复制 narrator prose；
- legacy 与 cache-first 可以改变顺序和标签，但不得改变可见原文、来源、时间和关系隔离语义。

### M4.1-D：把 SceneFrame 降级为 CurrentSceneEvidence

宿主内部可以继续使用 `SceneFrame` 类型和 frameId，但主模型只在原文窗口不足时接收精简的 `currentSceneEvidence`：

```ts
interface CurrentSceneEvidence {
  sceneId?: number
  place?: SourcedValue<string>
  presentPeople: SourcedValue<string>[]
  ongoingActivity?: SourcedValue<string>
  deviceAccess?: SourcedValue<string>
  privacy?: SourcedValue<string>
  attention?: SourcedValue<string>
  openLoops: SourcedValue<string>[]
}
```

不得从 narrator prose 的尾句写入 `narrativeFocus`、`postureOrMotion` 或任何同义字段。环境修辞、偶然道具、句式和收尾动作不属于状态。`workingDetails` 只保留仍未解决、仍与当前生活有关且有来源的具体事项；已解决项显式完成，而不是依靠数组尾部淘汰。

如果 recentScript 已经清楚包含当前地点、活动和姿态，相同证据不重复注入主提示。SceneFrame 主要服务宿主的检索、场景边界与行动能力判断。

### M4.1-E：修复跨日原始剧本召回

召回改为“索引命中，原文回取”：

```text
当前事件
  → 关键词 / 实体 / 日期 / 语义 / 未完成事项候选并集
  → 统一排序
  → 命中 entryId 或 fact.sourceEntryIds
  → 回取命中点前后的连续原始剧本
  → recalledScript
```

- 为 `interlude_script_entry` 注册可空 `embedding` 字段，使用幂等迁移并在后台渐进回填；
- 语义候选不能先被 importance/top-N 截断；高重要度、最近完成、未完成承诺、词法、日期实体与向量候选先取并集；
- 单个命中不只返回 300 字符摘要，应按关系可见性回取相邻条目和必要 narrator prose；
- Embedding 失败时保留词法、实体、时间和来源 entryId 回取；
- 相似 prose 只用于定位事件，不把大量同风格段落反复注入形成文风自模仿。

### M4.1-F：建立事件式 Scene / DialogueBurst 边界

Scene 由已经提交的生活变化结束：睡眠与新一天、明确换地点、主要活动切换、在场结构改变或现实目标转换。时间差只能触发边界检查，不能直接改变叙事精度。

DialogueBurst 表示局部互动因果链，可以在 Scene 不变时因问题落下、话题无因果转换、注意力回到生活或新外部事件打断而更新。它不再与 Scene 同寿命。修复 `entryCount` 每次压缩归零的问题，并让关闭决策携带具体来源事件和原因；压缩模型可以提出证据，宿主状态机负责确认。

### 涉及文件

- `src/narrator.ts`
- `src/database.ts`
- `src/service.ts`
- `src/types.ts`
- `src/story-state.ts`
- `src/script/context-compiler.ts`
- `src/script/scene-frame.ts`
- `test/narrative-prompts.test.ts`
- `test/payload-order.test.ts`
- `test/history-recall-guards.test.ts`
- `test/scene-frame.test.ts`
- `test/dialogue-burst.test.ts`
- 新增跨日召回、原文邻域回取和上下文完整性集成测试

### M4.1 完成门槛

- [ ] 有历史的实时回合中，原始 recentScript 注入率为 100%；
- [ ] SceneFrame 不再保存或回注任意 prose 尾句、修辞和偶然道具；
- [ ] 连续 20 轮不机械重复同一组场景道具、姿态和收尾动作；
- [ ] 前一日明确事件能通过事实或原文索引回取其连续原文；
- [ ] 未召回时不会断言事件从未发生；
- [ ] Scene 能按睡眠、地点和活动转换关闭，DialogueBurst 能在同一 Scene 内自然更新；
- [ ] Embedding 回填重启后仍存在，迁移运行两次结果一致；
- [ ] 0.1.4/beta3 与 M4.1 同模型盲评中，M4.1 连续性和人物感不低于基线；
- [ ] 私聊、群聊、引用、表情、图片、语音、延迟回复、自动推进、Schedule、Agency 与 Alter 冒烟通过；
- [ ] 单故事 24 小时与高密度故事 72 小时观察通过后，才允许开始 M5。

### 回退

M4.1 不删除原始条目、不重写历史 prose，也不建设第二条运行主链。回退依赖 beta1 源码/包与迁移前数据库备份；新增 embedding 列允许旧代码忽略。任何原文完整性门槛失败时，优先回退到 0.1.4 式 payload 投影，而不是继续给 SceneFrame 添加字段。

## 10. M5：Script-first 提交收束，不让主模型写事件表

### 路线修正

取消原计划“主模型原生返回完整 events、frameChanges 和 developmentEvidence”。该协议会让主模型同时写剧本、拆事件、填因果图和标注学习证据，与 0.1.2 已验证失败的认知过载结构过于接近。

M5 保留 M2 已有的内部 `ScriptCommitDraft`，但明确：模型的第一任务始终是写连续剧本；只有当前 phase 真正需要执行的平台动作才保留最小 transport 字段。事件 ID、来源 ID、commitId 和投递状态由宿主在提交边界生成。

### 主模型最小协议

```json
{
  "script": "同一部生活剧本的连续增量",
  "interaction": {
    "seen": true,
    "reply": {
      "mode": "none|immediate|delayed",
      "content": "必要时的可见消息",
      "sendAt": "仅 delayed 使用"
    }
  }
}
```

群聊、引用、表情、跨关系动作和 intent 仍按实际能力条件注入，不把所有可选 schema 常驻在每一轮提示中。消息文本必须已经自然出现在 `script` 的对应行动里；transport 字段只是宿主执行同一行动所需的句柄，不是第二条叙事链。

### 宿主侧提交

1. 为当前外部事件生成稳定 eventId；
2. 保存完整 script 原文为 commit 的权威文本；
3. 将必要 transport 动作规范化成带 eventId 的内部事件；
4. 验证可见消息与 script 中已经发生的消息一致；
5. 由宿主补充 commitId、frameId、burstId、来源和投递状态；
6. 低频压缩器只在剧本提交之后提取事实索引，不参与本轮写作。

不要用脆弱的全文字符串搜索证明消息存在。应在当前最小协议内保留一个轻量、局部的 script action 标记或由解析器绑定唯一消息段；它只标定 transport 对应位置，不要求模型描述完整事件图。

### 切换方法

- 先固定现有 beta10 输出经 adapter 形成的 `ScriptCommitDraft` 结果；
- 收窄每个 phase 实际注入和接受的字段；
- 把 commit/event 身份生成从 adapter 移到宿主提交边界；
- 确认所有下游只读取规范化 commit 后，删除运行中的 `legacy-adapter`；
- 本阶段不改数据库表、不改投递重试策略、不引入事件学习。

### 正向提示方式

提示模型只完成一件事：让当前事件进入正在发生的生活并写出下一段剧本。必要的可见回复是其中一个动作；主角没有回复时，剧本仍可以完整成立。协议说明与写作提示分区，transport schema 不取得叙事中心。

### 验证

- [x] 主输出没有通用 events、sceneState、sceneTrace、frameChanges 或 developmentEvidence 表；
- [ ] 每条执行中的可见消息在同一 script 中有唯一对应行动和相同文本；当前已建立 `bound | unbound | future` 宿主观测，硬门槛等待实机绑定率；
- [x] 合法沉默不触发缺失回复恢复；
- [x] 任一结构恢复重试都重写完整未提交回合，不单独补造消息；
- [x] 单轮主模型调用数不高于 M4.1；
- [ ] 与 M4.1 相同输入回放时，剧本质量不因协议收束下降；
- [ ] adapter 删除后内部 commit 快照保持等价。

### 暂缓项

实验性“script 完成前先发首泡”继续关闭。只有完整 script 与 transport 行动均已解析、因果位置已绑定后才能投递；流式优化不得先于原子剧本提交恢复。

## 11. M6：建立剧本行动的投递闭环

M6 不改变主模型写作，只把 M5 已规范化的 transport 行动变成可靠、可恢复的宿主事务。权威顺序是：先形成完整 ScriptCommit，再登记投递，再执行平台动作，最后把真实结果写回剧本现实。

### M6.1：使用现有表完成闭环

- 完整 transport action 保存在主 script entry metadata，携带 commitId、eventId 和 script action 位置；
- 拆分气泡、贴图、引用、原生表情和群聊动作只是同一行动的投递 segment；
- `confirmOutgoingDeliveries()` 按 eventId 汇总 `pending | delivered | partial | failed | cancelled`；
- `character-message` 只投影实际成功发送的内容，不成为第二份权威消息；
- 任一失败 segment 都保留明确结果，不能被前一个成功气泡掩盖；
- 下一轮主模型只读取必要的失败/部分投递事实，不读取内部重试状态表。

`1.0.0-beta3-m6` 已完成上述 metadata-only 闭环。当前主提示投影不会序列化内部 `deliveryActions`；已有 system outcome 条目继续以必要现实事实进入既有 recentScript 规则。

### M6.2：Outbox 原位迁移

第一阶段稳定后再新增：

```text
interlude_script_commit
interlude_delivery_outbox
interlude_delivery_outcome
```

迁移顺序：注册新表 → 从现有 metadata 回填 → 离线比较投影视图 → 一次性切换权威写入 → 停止旧写入 → 一个发布周期后删除兼容读取。回填期间不双写，不运行两套发送器。

Outbox 只负责执行已经存在于剧本中的行动，不能在失败重试时重新调用主模型或改写消息内容。

### 验证

- [x] 自动测试确认剧本行动、transport 内容与投递输入原文差异为 0；平台实机抽样待观察；
- [x] 所有气泡可按同一 eventId 重建为一个完整行动；ChatRhythm 仍读取完整回复，不消费 delivery segment；
- [ ] 崩溃/reload 发送去重待验证：M6.1 未新增发送器，但现有 pending intent 仍有发送成功后、完成记录前的崩溃窗口；
- [x] 账本支持幂等更新；本次源码修正 partial 必须包含实际成功 segment，未确认重试保留 pending；
- [x] 群聊、私聊、贴图、原生表情、引用和跨关系动作沿用同一 commitId/eventId 规则；
- [x] 平台失败只改 metadata outcome 并保留既有失败事实条目，不修改已提交原始剧本；
- [ ] Desktop 实机完成私聊、群聊、贴图、原生表情、引用、跨关系动作与部分失败抽样；
- [ ] M6.1 通过 24/72 小时稳定门槛后，才评估 M6.2 Outbox 原位迁移。

## 12. M7：场景检查点与 EpisodeIndex

### 2026-09-05 本轮源码实施与范围

- M7.3 提前执行：service 不再生成 ChatRhythm prompt，narrator 和 context compiler 均停止投影其 drift 指令。旧统计、配置和函数保留兼容，物理删除留到 M9；这些统计尚不用于人物学习。
- M6→M7 结果反馈：已通过当前关系可见性过滤的 script 条目，其非全部成功行动投影为 `ongoingThreads.deliveryReality`；记录源 entry/event 和必要 segment 内容，不传内部错误原因或重试时间。pending 为未确认，failed 为出错后未确认，平台接受不等于用户已读。跨关系行动再次按关系共享权限过滤。
- M7.1 检查点：只有现有宿主来源校验通过的 scene close 才登记 `sceneCheckpoint`，保存 sceneId、起止时间、首尾 entryId、边界原因和来源 ID，附着在原始边界证据 metadata。读取时可回到原文范围，不新增摘要文本或模型调用。旧场景不补造未经保存的边界证据。
- M7.2 首阶段：历史缓存保留 frameId/checkpoint；对已经过滤可见性的原文构建可丢弃的场景与关系索引。检查点覆盖旧条目，frameId 覆盖新剧本；沿用事实来源、词法、语义候选寻找命中点，再在该索引内回取原文。索引每次由缓存重建，检查点写入会使历史缓存失效重载。
- 原文截取优先保留真正命中的条目，再选取邻域；每个片段最多 4000 字符、最多三个片段，sourceEntryIds 只声明实际包含的原文。修复旧邻域从头截断可能丢失命中段的问题。

本轮 EpisodeIndex 是场景/关系级导航的首阶段，不宣称已完成实体、物件、承诺、结果等独立语义标签与跨场景事件合并。新检查点只保存边界和原文范围；起终点事实锚点与开放事项仍从原文和现有 facts 回取，尚未新增检查点事实快照。M5 轻量行动引用维持兼容状态，本轮不把 unbound 改成重试条件。

### 后续执行路径（本轮更新）

1. 固定连续场景回放，验证 deliveryReality 关系隔离、未确认语义、原文命中保留，以及停止节奏模板后的表达变化；真实拟真度尚不能由自动测试证明。
2. 收束 M5 局部行动引用，并补足 M7 EpisodeIndex 的人物/地点/物件/承诺/结果来源标签；标签只定位原文，不生成替代剧本的摘要。检查点起终点事实采用可追溯原文证据。
3. 进入 M8 前完成投递现实与计划的来源区分、记忆生产者/消费者审计；同一 Scene/burst 重复内容不累计为多份人格证据。然后处理低频人物发展、反证及时间导演瘦身。
4. M6.2 按崩溃恢复需求决定是否提前，明确未知平台结果，不能声称当前账本已实现发送幂等。
5. M9 在语义稳定后删除 ChatRhythm 旧指令函数与无消费者层，再拆分 service；M10 执行兼容回归、24/72 小时运行和同模型连续场景盲评。

本批次保持版本号、已构建 lib、发布包和 Desktop 实例不变。

M7 不建立新的“场景真相”，而是在已提交原始剧本之上建立可丢弃、可重建的索引。任何索引损坏都不得要求改写历史剧本。

### M7.1：SceneCheckpoint

只有宿主确认结构性场景边界后才生成检查点。检查点保存：

- sceneId、起止 entryId 与本地时间范围；
- 起点和终点的少量事实锚点；
- 已完成动作、仍开放事项和参与关系；
- 相关原始条目 ID；
- 边界类型与边界证据。

检查点摘要用于定位原文，不能直接成为下一轮的写作模板。活跃 Scene 的状态来自近期原文和已确认事件，不从摘要反推 prose。

### M7.2：EpisodeIndex

以事件语义而不是文风相似度建立索引：人物、地点、物件、话题、承诺、结果、日期和关系分支。检索命中 Episode 后回取原始条目邻域；索引只回答“去哪一段找”，不回答“当时具体怎么发生”。

EpisodeIndex 必须可从 `interlude_script_entry` 和来源 ID 全量重建。摘要、embedding 或标签出错时，删除索引重建即可，原始历史保持不变。

### M7.3：逐步停用 ChatRhythm 的负向注入

- 先保留统计和日志，但停止向主提示发送“这轮必须改变气泡数/长度”的反向命令；
- 统计单位改为 M6 的完整 transport 行动，不按 segment 重复计算；
- 删除 sticky exhausted、强制轮换和基于尾部重复次数的写作指令；
- 若保留习惯投影，只能来自跨 Scene 的稳定观察，并用一两句正向概率表达；
- 未证明正向习惯投影优于无投影前，不建立新的 DialogueHabitProfile 数据表。

### 验证

- [ ] 所有 SceneCheckpoint 和 Episode 均能回溯到连续原始 entryId；
- [ ] 删除索引后可以从原始剧本重建等价的检索入口；
- [ ] 同一高密度 burst 不被拆成多个虚假 Episode；
- [ ] Episode 命中后注入的是相关原文邻域，而不是只有摘要；
- [ ] Scene 摘要措辞不会连续复制进下一轮 prose；
- [ ] 停止 ChatRhythm 注入后，结构解析率和平台投递不受影响；
- [ ] 对话气泡变化来自人物与场景，而不是宿主强制轮换。

## 13. M8：收敛时间、记忆与人物学习

M8 只消费已经稳定的原始剧本、EpisodeIndex 和投递结果。它不再改变实时主提示的中心结构。

### M8.1：时间导演瘦身

- 实时用户消息继续不调用时间导演；
- conversation follow-up 和短 due 窗口直接从 recentScript 的未完成动作续写；
- 只有跨越较长后台空档且 Schedule/intent 不能提供足够结构时才生成 BeatSkeleton；
- BeatSkeleton 是已经校验的时间窗口内可发生结构，不规定 prose 篇幅和事件密度；
- 时间模型失败时缩短窗口或等待下次推进，不用自由 prose 猜测大段时间；
- 宿主继续权威处理绝对时间、用户明确报告时间、日程边界和已完成 timeline ledger。

### M8.2：记忆层生产者—消费者审计

| 层 | M8 处理 |
| --- | --- |
| recentScript | 永久保留为连续剧本原文和第一续写上下文 |
| recalledScript | 由 Episode/fact/词法/语义命中后回取的历史原文 |
| SceneFrame | 宿主内部当前证据索引；仅在原文窗口不足时精简投影 |
| facts | 带 sourceEntryIds 的长期检索索引，不直接代替发生过程 |
| continuitySnapshot | 只保存原文窗口外仍影响现在的低频连续性 |
| workingDetails | 并入带生命周期的 open loops；已解决项显式结束 |
| memory 表 | 无独立生产者或消费者时停止写入、验证后删除 |
| delivery summaries | 由 ScriptCommit 与 delivery outcome 确定性投影 |
| timelineCarry | 只保存宿主已确认但尚未完成的 beat，不保存 prose 尾句 |

每次只处理一层：先观测真实消费，再停止写入，再比较关闭读取前后的召回率，最后删除。原始剧本层永不参与此类删除。

### M8.3：人物发展与对话习惯

人物学习从 SceneCheckpoint 的原始证据中低频产生，不在主模型实时输出中索取 `developmentEvidence`：

1. 定义少量受控 dimension 和 global/relationship scope；
2. 压缩任务按 sourceEntryIds 提出候选证据；
3. 一个观察周期只记录、不应用；
4. 同一 burst 和同一 Scene 的重复表现合并为一次贡献；
5. 只有跨 Scene 重复证据或明确重大事件才晋升；
6. 反证降低置信度，当前情绪只留在当前剧本；
7. 停止新的自由路径 statePatch，旧 patch 可映射则迁移，否则归档。

投影给主模型的只能是一两句自然、正向、概率式倾向，且仅在当前事件相关时出现。它不能规定本轮气泡数、句长、标点或强制制造变化。

### 验证

- [ ] payload 每一层有明确生产者、消费者、来源和生命周期；
- [ ] 删除冗余层后原文注入率与历史事件召回率不下降；
- [ ] 相似 prose 不会因向量召回持续自我强化；
- [ ] 相同消息重复十次不会产生十倍人格权重；
- [ ] 所有稳定发展均能回溯到跨 Scene 原始剧本；
- [ ] 关系限定习惯不污染全局人物模型；
- [ ] 连续运行数日后人物变化缓慢可见，无长期零变化或单次突变；
- [ ] 时间导演调用减少后，长空档时间正确率不下降。

## 14. M9：删除临时结构并完成物理模块化

只有 M4.1–M8 的语义、迁移和真实运行均稳定后，才进行大文件拆分与旧代码删除。M9 不再改变提示词、召回排序、学习权重或投递语义；否则无法区分行为回归来自清理还是架构变化。

### 删除项

- M5 已停止消费的 `legacy-adapter`；
- 已被最小 phase transport 协议替代的兼容字段；
- ChatRhythm 旧实现和配置；
- 自由路径 statePatch 应用器；
- 无生产者的 memory 路径；
- 实时窗口的冗余时间规划代码；
- `story.state` 中已经迁移并验证的旧字段；
- 围绕文学形式的反重复检测和重试。

不得删除或压平：

- `interlude_script_entry` 原始 prose、真实收发消息和时间戳；
- recentScript 的可见性与关系隔离逻辑；
- 从事实、Episode 和 SceneCheckpoint 回取原文的来源链；
- 0.1.4 剧本核心提示词的角色定位与原文权威顺序。

### 最终模块结构

```text
src/script/
  contract.ts
  context-compiler.ts
  scene-frame.ts
  author.ts
  validator.ts
  persistence.ts
  projection.ts
  delivery-outbox.ts
  dialogue-habits.ts
  development.ts
  episode-index.ts
  scene-checkpoint.ts
  recall.ts
```

`service.ts` 只保留 Koishi 生命周期、故事队列和调度。`narrator.ts` 最终拆为模型传输、任务路由和各任务 prompt builder，不再保存整个业务架构。

### 验证

- [ ] 删除任何旧模块后测试仍通过；
- [ ] `rg` 不再找到旧字段的运行时消费者；
- [ ] 发布包只包含当前文档和当前协议；
- [ ] 从 beta10 数据库升级时迁移只运行一次；
- [ ] 新安装与升级安装产生等价的当前状态结构；
- [ ] 拆分前后同一冻结 payload 逐字段等价，recentScript 原文逐字一致；
- [ ] M9 前后固定模型回放没有新增问答器化、复读或跨日失忆。

## 15. M10：整体运行可行性与拟真度发布门

### 15.1 静态和单元验证

每个里程碑都必须运行：

```text
npm run typecheck
npm test
```

最终应新增以下测试族：

- 状态 codec 和幂等迁移；
- ScriptCommit 协议；
- prose/event/message 一致性；
- SceneFrame 来源和不可变性；
- DialogueBurst 高密度连续性；
- recentScript 非空与字符/消息保护门槛；
- 历史命中后的原文邻域回取；
- embedding schema、回填和重启持久化；
- 结构性 Scene 边界与同 Scene 内 Burst 更新；
- 投递 Outbox 重启恢复；
- 场景级学习去重；
- 旧数据库升级；
- 模型路由确定性；
- 正向提示词结构。

### 15.2 数据库迁移演练

必须在运行数据库副本上执行，而不是第一次直接改生产库：

1. 复制数据库；
2. 使用 beta10 打开并记录表数、故事数、entry 数和关键状态；
3. 使用当前里程碑版本升级；
4. 重启两次验证迁移幂等；
5. 对比所有旧 script 原文、真实收发消息和 occurredAt；
6. 检查 embedding、commit、event、SceneCheckpoint 和 Episode 索引回填数量；
7. 用新版本推进若干轮；
8. 验证旧剧本仍可检索和压缩；
9. 从备份恢复一次，确认回退步骤真实可用。

### 15.3 运行冒烟

至少覆盖：

- 私聊单条消息；
- 私聊快速连续消息；
- 群聊和引用；
- 自然沉默；
- 延迟回复和 conversation follow-up；
- 自动推进；
- intent 到期；
- 贴图、表情和动作；
- 模型超时与格式错误；
- 投递部分失败；
- 插件 reload 和进程重启。

必须确认：

- 没有重复模型调用；
- 没有重复投递；
- 故事游标单调前进；
- pending commit 能恢复；
- 消息事件与发送原文完全一致；
- SceneFrame 重载后不丢失；
- SceneFrame 不含 prose 尾句和偶然道具回声；
- 跨日相关事件能回取原始剧本；
- 检索未命中时人物不做“从未发生”的错误断言；
- 失败功能不会阻塞其它故事队列。

### 15.4 稳定性观察

建议按以下节奏扩大使用：

1. M4.1 单一测试故事运行 24 小时；
2. 包含高密度对话、跨日和重启的测试故事运行 72 小时；
3. 数据库副本上模拟七天定时任务、压缩、Scene 切换、索引回填和事实增长；
4. 使用同一组冻结输入顺序回放 0.1.4/beta3、1.0.0-beta1 与当前候选；
5. 再进入真实主故事的小范围连续运行；
6. 每个阶段只升级一个里程碑，观察稳定后继续。

### 15.5 发布决策

M10 不是开发结束后的形式检查，而是每个候选版本能否继续推进的发布门。以下任一情况出现即停止升级：

- 原始剧本在有历史的正常实时回合中缺席；
- 辅助结构覆盖原文或把 prose 措辞循环回注；
- 前一日明确事件存在但多通道召回无法触达；
- 高密度消息导致情节数量或人格权重随条数增长；
- 主模型为了填写结构化副产物而明显降低剧本质量；
- 原有平台能力、投递幂等或数据库恢复出现退化。

通过 M10 后才允许把当前路线称为 V2 稳定架构；版本号是否进入 RC 由真实运行和盲评结果决定，不由里程碑编号自动决定。

## 16. 拟真度验证表

拟真度必须评价整段剧本，不能只截取角色回复。

### 16.1 连续生活

- [ ] 用户不发消息时，主角仍有自己的活动和未完成动作；
- [ ] 用户消息进入已有生活，而不是让世界重新围绕问题开场；
- [ ] 高频对话不反复重设地点、姿态和情绪；
- [ ] 短窗口没有降低事件语义精度；
- [ ] 长窗口没有凭空填满琐碎事件；
- [ ] 场景结束来自生活变化，而不是每轮固定收束。

### 16.2 剧本与消息耦合

- [ ] 每条消息都能在同一 ScriptCommit 中找到感知、动作或情绪因果；
- [ ] 可见消息不是对用户文本的通用问答改写；
- [ ] 单独删除消息事件后，剧本因果会出现真实缺口；
- [ ] 沉默在剧本中成立，而不是因为字段缺失；
- [ ] 回复后的生活延续与消息内容相互影响；
- [ ] 平台失败会成为后续世界事实。

### 16.3 高密度稳定性

- [ ] 同一语义拆成 1、5、10 条消息时，人物核心态度基本一致；
- [ ] 消息越密集不会自动产生越多新情节；
- [ ] 语言不会因窗口缩短而突然变得概括、模板化或失去人物声音；
- [ ] 原有场景事实不会在逐轮复述中漂移；
- [ ] 同一 burst 只对长期学习贡献一次场景权重；
- [ ] 人格变化幅度不与消息条数成比例。

### 16.4 人物发展

- [ ] 人物变化缓慢但能观察到；
- [ ] 每项稳定变化有跨场景或重大事件证据；
- [ ] 即时情绪不会晋升成永久性格；
- [ ] 面对不同参与者的关系习惯保持隔离；
- [ ] 对话习惯表现为自然范围，不表现为系统强制轮换；
- [ ] 反证能够降低旧结论而非继续叠加。

### 16.5 正向框架质量

- [ ] 主提示词主要描述“如何继续生活”，而不是罗列禁止事项；
- [ ] 风格提示以正向声音、焦点和动作惯性为主；
- [ ] 不使用固定字数、固定气泡数和固定结尾作为拟真手段；
- [ ] 写作失败不会触发越来越长的反例清单；
- [ ] 宿主重试只针对结构或现实性错误；
- [ ] 模型能在没有惩罚式 ChatRhythm 的情况下产生条件化变化。

## 17. 建议量化指标和通过线

以下指标用于比较 0.1.4/beta3 叙事基线、beta10 冻结回放、1.0.0-beta1 实机失败夹具与每个新里程碑。它们不是文学评分的替代品，而是防止架构性退化。

| 指标 | 最低通过线 |
| --- | --- |
| 主模型单轮调用数 | 不高于 beta10 对应 phase；结构重试单独记录 |
| ScriptCommit 解析成功率 | 不低于 beta10 decision 解析成功率 |
| 剧本消息与投递原文差异 | 0 |
| 无所属 commit 的角色消息 | 0 |
| 无来源 SceneFrame 变化 | 0 |
| 重启后重复投递 | 0 |
| 状态 decode/encode 字段丢失 | 0 |
| 有历史实时回合的 recentScript 注入率 | 100% |
| recentScript 原文迁移/编译差异 | 0；只允许显式的安全清洗和紧凑 metadata 投影 |
| 前一日明确事件召回率 | 冻结夹具 100%，扩展样本不得低于基线 |
| 检索缺席导致的错误“从未发生”断言 | 0 |
| 原始剧本 embedding 重启保留率 | 100% |
| 重复同一 burst 十次带来的长期权重 | 不超过一次 Scene 贡献上限 |
| 高密度夹具的无因果新 beat | 0 |
| 连续 20 轮偶然道具/姿态机械复现 | 0 个系统性模板循环 |
| Scene/Burst 跨日异常长寿命 | 无跨越明确结构边界而未关闭的实例 |
| 旧剧本原文和时间戳迁移差异 | 0 |
| 关键场景连续性人工盲评 | 多数评审偏好新版本，且无严重问答器化案例 |
| 七日模拟后的稳定人格突变 | 0 个无证据突变 |

人工盲评至少同时展示前置剧本、本轮外部事件、本轮剧本和后续一轮。只看单条回复会错误奖励问答器式的即时贴合。

## 18. 每个里程碑的提交表单

每一步开始和结束时填写：

```text
里程碑编号：
目标行为：
本次唯一主要变量：
涉及源文件：
涉及数据字段/表：
是否改变模型协议：
是否改变数据库：
是否改变投递：
是否改变长期学习：

实施前：
[ ] 源码备份可读取
[ ] 数据库备份可恢复
[ ] 基线夹具已运行
[ ] 上一里程碑通过全部门槛

实施后：
[ ] typecheck 通过
[ ] 全部单元测试通过
[ ] 新增集成测试通过
[ ] 数据迁移幂等
[ ] 单轮只有一次主模型调用
[ ] 没有重复投递
[ ] 日志可定位 commitId/eventId
[ ] 离线回放已与基线比较
[ ] 人工审阅连续剧本而非孤立回复

观察结果：
运行时长：
解析成功率：
结构重试率：
投递失败率：
高密度漂移情况：
拟真度盲评结果：

进入下一步的理由：
已知风险：
回退点：
负责人/日期：
```

任何一项关键门槛未通过，就停留在当前里程碑修复；不能一边保留已知断裂，一边继续叠加下一层新架构。

## 19. M4.1 时期的推进批次（历史记录；当前执行顺序见第 2 节新 M7.1）

M1–M4 已完成，当前唯一允许开始的工作是 M4.1。建议拆成以下可独立回放的小批次，每批只改变一个主要变量：

1. **夹具与备份**：冻结 beta1 实机日志、运行数据库副本、0.1.4 system prompt 和相同模型输入；不改行为。
2. **提示主权恢复**：恢复 0.1.4 剧本核心和 recentScript 第一解释权，把 SceneFrame 改成从属的 `currentSceneEvidence`；暂不改检索算法。
3. **停止 prose 回注**：删除 tail-clause 物化，清理 workingDetails 生命周期；暂不改数据库。
4. **召回修复**：增加 script-entry embedding 迁移、多通道候选并集和原文邻域回取；暂不改输出协议。
5. **Scene/Burst 边界**：使用已提交事件确认结构转换，修复 entryCount 与关闭证据；不使用固定时间改变叙事精度。
6. **兼容与实机门槛**：跑完整小功能清单、24/72 小时观察和三版本盲评；全部通过后才开始 M5。

M5 不再让主模型原生填写完整事件图，而是收束为 script-first 提交；M6 只处理投递事务；M7 在原文之上建立可重建索引；M8 再收敛时间、记忆和人物学习；M9 仅做删除与物理拆分；M10 负责最终发布判断。

这条路径仍然只维护一条真实运行主链。V2 的结构能力围绕原始剧本生长，并且始终可以从原文重建；它不再尝试用结构化状态替代剧本本身。
# 2026-09-06 补充：P1-1～P1-4 渐进记忆导航（已并入 beta8）

本轮在 beta7-enhanced 原位实现，不创建平行叙事链。工作细节以原文修订和显式同事项交接替代模糊合并；历史向量以可恢复分页及新旧额度覆盖旧档案；细节使用本地原文跨度索引，不为小段新增模型请求；主叙事／时间导演按到期事项与有来源 topic 查询原文，后台预算一段并保留隐私边界。

保留剧本中心、原文、联系悬念和现有投递链路；不做 P0-3，不清理旧数据库。早期 263 项测试与编译通过；beta8 发布前已重新完成全量 283 项测试、严格类型检查与构建，拟真度仍需后续实机验收。完整设计取舍、性能记录和限制见 [P1 实现记录](development/P1_MEMORY_NAVIGATION.md)。
